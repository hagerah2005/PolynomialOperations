#include "Polynomial.h"

int main() {

    // test1 -success
    Polynomial p1({3, -4, 2});
        cout << "Polynomial p1: " << p1 << endl;
        cout << "Degree of p1: " << p1.degree() << endl;

     //test2 // success
    Polynomial p2({1, 5});
         cout << "Polynomial p2: " << p2 << endl;
         cout << "Degree of p2: " << p2.degree() << endl;

    //test3 // success
        Polynomial p3({2, -1, 3});
        cout << "Polynomial p3: " << p3 << endl;
        cout << "Degree of p3: " << p3.degree() << endl;


                //test4 //Failed // No polynomial and degree must be zeros
            Polynomial p4({0, 0, 0, 0});
                 cout << "Polynomial p4: " << p4 << endl;
                cout << "Degree of p4: " << p4.degree() << endl;

             //test5 // Failed //the term 0x^2 must not found
            Polynomial p5({10, 0, 8e50});
                 cout << "Polynomial p5: " << p5 << endl;
                 cout << "Degree of p5: " << p5.degree() << endl;

            //test6 //success
             Polynomial p6;
                cout << "Polynomial p6: " << p6 << endl;
                cout << "Degree of p6: " << p6.degree() << endl;


    Polynomial p7({10, 20, 5, -3,5});
    cout << "Polynomial p7: " << p7 << endl;
    Polynomial p8({-8, 7, 9, 1});
    cout << "Polynomial p8: " << p8 << endl;
    Polynomial p9({0, 2, 17, 23,62,-5});
    cout << "Polynomial p9: " << p9 << endl;
    // Operations between polynomials
    cout << "\n first Operations between polynomials:" << endl;

    Polynomial sum = p7 + p9;//test7 //success
         cout << "p7 + p9: " << sum << endl;
    Polynomial difference = p8 - p7;//test8 //success
        cout << "p8 - p7: " << difference << endl;
    Polynomial product = p9 * p8;//test9 //success
        cout << "p9 * p8: " << product << endl;


        Polynomial p10({11, 1, -14, 5, -5, 13, 7, -11, 15, -13});
            cout << "Polynomial p10: " << p10 << endl;
        Polynomial p11({6, -5, 12, -7, 4, 8, 11, -1, 13, -4});
            cout << "Polynomial p11: " << p11 << endl;

            // Operations between polynomials
            cout << "\n Second Operations between polynomials:" << endl;
        Polynomial sum2 = p10 + p11;//test10 //success
                cout << "p10 + p11: " << sum << endl;
        Polynomial difference2 = p10 - p11;//test11 //success
                cout << "p10 - p11: " << difference << endl;
        Polynomial product2 = p10 * p11;//test12 //success
                cout << "p10 * p11: " << product << endl;

        Polynomial p12({-10e10,20,20e3000});
                cout << "Polynomial p12: " << p12 << endl;
        Polynomial p13({0,-500});
                cout << "Polynomial p13: " << p13 << endl;

        // Operations between polynomials
        cout << "\n Third Operations between polynomials:" << endl;
        Polynomial sum3 = p12 + p13;//test13 //Failed //infinity on first term
                cout << "p12 + p13: " << sum << endl;
        Polynomial difference3 = p12 - p13;//test14 //Failed //infinity in first term
                cout << "p12 - p13: " << difference << endl;
        Polynomial product3 = p12 * p13;//test15 //Failed //negative infinity in first tem & nan in the second term
                cout << "p12 * p13: " << product << endl;



    // Equality check
    cout << "\n Equality check:" << endl;
    Polynomial p14({0,15,500});
            cout << "Polynomial p14: " << p14 << endl;
    Polynomial p15({15,-25});
            cout << "Polynomial p15: " << p15 << endl;
    Polynomial p16({15,-25});
            cout << "Polynomial p16: " << p16 << endl;
    cout << "p14 == p15: " << (p14 == p15) << endl;   //test16 // success
    cout << "p15 == p16: " << (p15 == p16) << endl;   //test17 // success
    cout << "p14 == p16: " << (p14 == p16) << endl;   //test18 // success




    // Evaluate polynomial
    Polynomial p17({2e50,5e50});
        cout << "Polynomial p17: " << p17 << endl;
    double evaluationPoint = 3;
    cout << "\np17 evaluated at x = " << evaluationPoint << ": " << p17.evaluate(evaluationPoint) << endl; //test19 //success

    Polynomial p18({2e500,5e50});
         cout << "Polynomial p18: " << p18 << endl;
    double evaluatPoint = 5e200;
    cout << "\np18 evaluated at x = " << evaluatPoint << ": " << p18.evaluate(evaluatPoint) << endl;//test20 //Failed //constant not infinity

    // Derivative
    Polynomial p19({15,15,20});
         cout << "Polynomial p19: " << p19 << endl;
    cout << "\nDerivative of p19: " << p19.derivative() << endl; // test21 //success
    Polynomial p20({15, 6, -8, 0, -7});
         cout << "Polynomial p20: " << p20 << endl;
    cout << "\nDerivative of p20: " << p20.derivative() << endl; //test22 //Failed //term 0x^2 must not found
    Polynomial p21({0,20e500});
         cout << "Polynomial p21: " << p21 << endl;
        cout << "\nDerivative of p21: " << p21.derivative() << endl;//test23 //failed //should give constant not infinity

    // Integral
    Polynomial p22({5, -1, 3, -10, 9, 3, -1, -2, -9, 15, 9});
         cout << "Polynomial p22: " << p22 << endl;
    cout << "Integral of p22: " << p22.integral() << endl;//test24 //success
   Polynomial p23({0,0});
        cout << "Polynomial p23: " << p23 << endl;
   cout << "Integral of p23: " << p23.integral() << endl;//test25 //failed //must equal zero
   Polynomial p24({0,20e2});
        cout << "Polynomial p24: " << p24 << endl;
   cout << "Integral of p24: " << p24.integral() << endl;//test26 //failed //term 0x^1 must not found


    // Definite integral
    Polynomial p25({-11, 10, -14, -14, 0, -9, -7, 13});
        cout << "Polynomial p25: " << p25 << endl;
    double integralResult = p25.integral(0, 1);
    cout << "Definite integral of p25 from 0 to 1: " << integralResult << endl; // test27 //success

    Polynomial p26({10,5,65});
        cout << "Polynomial p26: " << p26 << endl;
    double integResult = p26.integral(5, 5);
        cout << "Definite integral of p26 from 5 to 5: " << integResult << endl;//test28 //success

    Polynomial p27({0,0,0,0});
            cout << "Polynomial p27: " << p27 << endl;
        double integ_Result = p27.integral(-500e200,500e200);
            cout << "Definite integral of p27 from -500e200 to 500e200: " << integ_Result << endl;//test29 //failed //must be zero

    Polynomial p28({10,50});
            cout << "Polynomial p28: " << p28 << endl;
    double int_Result = p28.integral(-1,10);
            cout << "Definite integral of p28 from -1 to 10: " << int_Result << endl;//test30 //success

    // Composition of polynomials
    Polynomial p29({1,2});
        cout << "Polynomial p29: " << p29 << endl;
    Polynomial p30({-2,5,8});
        cout << "Polynomial p30: " << p30 << endl;

    Polynomial comp = p29.compose(p30);
    cout << "Composition of p29 with p30: " << comp << endl;//test31 //success

    Polynomial p31({2e200,5000});
            cout << "Polynomial p31: " << p31 << endl;
    Polynomial p32({-2,5,8});
            cout << "Polynomial p32: " << p32 << endl;

    Polynomial compo = p32.compose(p31);
    cout << "Composition of p32 with p31: " << compo << endl;//test32 //Failed //term 3 must be constant not infinity

    Polynomial p_32({0,1,0});
            cout << "Polynomial p32: " << p_32 << endl;
    Polynomial p33({1,0});
            cout << "Polynomial p33: " << p33 << endl;

    Polynomial composition = p_32.compose(p33);
        cout << "Composition of p_32 with p33: " << composition << endl;//test33 //SUCCESS

    Polynomial p34({0,0,2e2588});
            cout << "Polynomial p34: " << p34 << endl;
    Polynomial p35({1,5});
            cout << "Polynomial p35: " << p35 << endl;

    Polynomial composition_2 = p34.compose(p35);
            cout << "Composition of p34 with p35: " << composition_2 << endl;//test33 //Failed //big coefficient denoted as infinity

    // Root finding
    Polynomial p36({-4,8,11});
        cout << "Polynomial p36: " << p36 << endl;
    double root = p36.getRoot(1,1e-6,10000);
    cout << "Root of p36 : " << root << endl;//test34 //success

    Polynomial p37({1,0,1});
        cout << "Polynomial p37: " << p37 << endl;
    double root2 = p37.getRoot(1,1e-6,10000);
    cout << "Root of p37 : " << root2 << endl;//test35 //failed //root must be i or -i

    Polynomial p38({15});
        cout << "Polynomial p38: " << p38 << endl;
    double root3 = p38.getRoot(1,1e-6,10000);
    cout << "Root of p38 : " << root3 << endl; //test 36 //failed //no root

    Polynomial p39({-1,-2,-5});
        cout << "Polynomial p39: " << p39 << endl;
    double root4 = p39.getRoot(1,1e-6,10000);
    cout << "Root of p39 : " << root4 << endl;//test37 //failed //it must be imaginary numbers not real

    Polynomial p40({0,1});
        cout << "Polynomial p40: " << p40 << endl;
    double root5 = p40.getRoot(1,1e-6,10000);
    cout << "Root of p40 : " << root5 << endl;//test38 //success

    Polynomial p41({-14, -5, 8, -5, 0, -7, 6, 4, 1, 15});
        cout << "Polynomial p41: " << p41 << endl;
    double root6 = p41.getRoot(1,1e-6,10000);
    cout << "Root of p41 : " << root6 << endl;//test39 //success

    Polynomial p42({-14, -5, 8, -5, 0, -7, 6,2000e7000});
        cout << "Polynomial p42: " << p42 << endl;
    double root7 = p42.getRoot(1,1e-6,10000);
    cout << "Root of p42 : " << root7 << endl;//test40 //failed //nan because of big numbers

    // Get coefficient
    Polynomial p43({-14, -5, 8, -5, 0, -7});
        cout << "Polynomial p43: " << p43 << endl;
    double coefficient = p43.getCoefficient(4); // Coefficient of x^4
    cout << "Coefficient of x^4 in p43: " << coefficient << endl;//test41 //success

    Polynomial p44({-14});
        cout << "Polynomial p44: " << p44 << endl;
    double coefficient2 = p44.getCoefficient(3);
    cout << "Coefficient of x^3 in p44: " << coefficient2 << endl;//test42 //success

    Polynomial p45({17,-5,-25e2587});
            cout << "Polynomial p45: " << p45 << endl;
    double coefficient3 = p45.getCoefficient(2);
    cout << "Coefficient of x^1 in p45: " << coefficient3 << endl;//test43 //failed //25e2587 not negative infinity

    Polynomial p46({150,280});
        cout << "Polynomial p46: " << p46 << endl;
    double coefficient4 = p46.getCoefficient(1);
    cout << "Coefficient of x^-1 in p46: " << coefficient4 << endl;//test44 //success

    // Set new coefficients
    Polynomial p47({150,280});
        cout << "Polynomial p47: " << p47 << endl;
    p47.setCoefficients({4, 1, -5});
    cout << "New p47: " << p47 << endl;
    // Get new coefficient
   double get_coefficient = p47.getCoefficient(2);
    cout << "Coefficient of x^2 in new p47: " << get_coefficient << endl;//test 45 //success

    Polynomial p48({10,170});
        cout << "Polynomial p48: " << p48 << endl;
    p48.setCoefficients({-2,-8000e400,50,80e20,987,6548e8527});
    cout << "New p48: " << p48 << endl;
    // Get new coefficient
   double get_coefficient2 = p48.getCoefficient(5);
    cout << "Coefficient of x^5 in new p48: " << get_coefficient2 << endl;//test46 //failed //coefficient 6548e8527 not infinity

    Polynomial p49({5,8,21});
            cout << "Polynomial p49: " << p49 << endl;
        p49.setCoefficients({-5});
        cout << "New p49: " << p49 << endl;
        // Get new coefficient
       double get_coefficient3 = p49.getCoefficient(0);
        cout << "Coefficient of x^0 in new p49: " << get_coefficient3 << endl;//test47 //success

        Polynomial p50({7, 0, -14, 2, 4, -11, -6, -14, 6});
                cout << "Polynomial p50: " << p50 << endl;
            p50.setCoefficients({0, 9, 15, 6, 0, 6, -8, 12, 13});
            cout << "New p50: " << p50 << endl;
            // Get new coefficient
           double get_coefficient4 = p50.getCoefficient(7);
            cout << "Coefficient of x^7 in new p50: " << get_coefficient4 << endl;//test48 //success

        Polynomial p51({0});
            cout << "Polynomial p51: " << p51 << endl;
        p51.setCoefficients({15,87,1,0,});
        cout << "New p51: " << p51 << endl;
        // Get new coefficient
       double get_coefficient5 = p51.getCoefficient(1);
        cout << "Coefficient of x^1 in new p51: " << get_coefficient5 << endl;//test49 //success

        Polynomial p52({0,0,0,0,-1});
            cout << "Polynomial p52: " << p52 << endl;
        p52.setCoefficients({-1,0,0,0});
        cout << "New p52: " << p52 << endl;
        // Get new coefficient
       double get_coefficient6 = p52.getCoefficient(0);
        cout << "Coefficient of x^7 in new p52: " << get_coefficient6 << endl;//test50 //success

    return 0;
}