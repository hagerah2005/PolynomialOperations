#include "Polynomial.h"
#include <iostream>
#include <vector>
#include <cmath> // Include this for pow and fabs
#include <algorithm>
#include <iomanip>

using namespace std;

// Default constructor
Polynomial::Polynomial() : coeffs(1, 0.0) {}

// Coefficient constructor
Polynomial::Polynomial(const vector<double>& coefficients) : coeffs(coefficients) {}

// Copy constructor
Polynomial::Polynomial(const Polynomial& other) : coeffs(other.coeffs) {}

// Destructor
Polynomial::~Polynomial() {}

// Assignment operator
Polynomial& Polynomial::operator=(const Polynomial& other) {
    if (this != &other) {
        coeffs = other.coeffs;
    }
    return *this;
}

// Addition operator
Polynomial Polynomial::operator+(const Polynomial& other) const {
    size_t maxSize = max(coeffs.size(), other.coeffs.size());
    vector<double> result(maxSize, 0.0);

    for (size_t i = 0; i < maxSize; ++i) {
        if (i < coeffs.size()) result[i] += coeffs[i];
        if (i < other.coeffs.size()) result[i] += other.coeffs[i];
    }
    return Polynomial(result);
}

// Subtraction operator
Polynomial Polynomial::operator-(const Polynomial& other) const {
    size_t maxSize = max(coeffs.size(), other.coeffs.size());
    vector<double> result(maxSize, 0.0);

    for (size_t i = 0; i < maxSize; ++i) {
        if (i < coeffs.size()) result[i] += coeffs[i];
        if (i < other.coeffs.size()) result[i] -= other.coeffs[i];
    }
    return Polynomial(result);
}

// Multiplication operator
Polynomial Polynomial::operator*(const Polynomial& other) const {
    vector<double> result(coeffs.size() + other.coeffs.size() - 1, 0.0);

    for (size_t i = 0; i < coeffs.size(); ++i) {
        for (size_t j = 0; j < other.coeffs.size(); ++j) {
            result[i + j] += coeffs[i] * other.coeffs[j];
        }
    }
    return Polynomial(result);
}

// Equality operator
bool Polynomial::operator==(const Polynomial& other) const {
    return coeffs == other.coeffs;
}

// Output operator
ostream& operator<<(ostream& out, const Polynomial& poly) {
    for (int i = poly.coeffs.size() - 1; i >= 0; --i) {
        out << poly.coeffs[i];
        if (i > 0) out << "x^" << i << " + ";
    }
    return out;
}

// Degree of polynomial
int Polynomial::degree() const {
    return coeffs.size() - 1;
}

// Evaluate polynomial
double Polynomial::evaluate(double x) const {
    double result = 0.0;
    for (int i = 0; i < coeffs.size(); ++i)
        result += coeffs[i] * pow(x, i); // Use std::pow
    return result;
}

// Derivative
Polynomial Polynomial::derivative() const {
    if (coeffs.size() <= 1) return Polynomial();

    vector<double> derivedCoeffs(coeffs.size() - 1);
    for (int i = 1; i < coeffs.size(); ++i) {
        derivedCoeffs[i - 1] = i * coeffs[i];
    }
    return Polynomial(derivedCoeffs);
}

// Integral
Polynomial Polynomial::integral() const {
    vector<double> integralCoeffs(coeffs.size() + 1);
    integralCoeffs[0] = 0; // constant of integration (C)
    for (int i = 0; i < coeffs.size(); ++i) {
        integralCoeffs[i + 1] = coeffs[i] / (i + 1);
    }
    return Polynomial(integralCoeffs);
}

// Integrate over a range
double Polynomial::integral(double x1, double x2) const {
    return integral().evaluate(x2) - integral().evaluate(x1);
}

// Get root using Newton's method
double Polynomial::getRoot(double guess, double tolerance, int maxIter) {
    for (int i = 0; i < maxIter; ++i) {
        double eval = evaluate(guess);
        double evalDeriv = derivative().evaluate(guess);
        if (fabs(evalDeriv) < tolerance) break; // Use std::fabs
        double nextGuess = guess - eval / evalDeriv;
        if (fabs(nextGuess - guess) < tolerance) return nextGuess;  // Use std::fabs
        guess = nextGuess;
    }
    return guess; // Return the last guess
}

void Polynomial::setCoefficients(const vector<double>& coefficients) {
    coeffs = coefficients;
}

double Polynomial::getCoefficient(int degree) const {
    return degree < coeffs.size() ? coeffs[degree] : 0.0;
}

// Composition of two polynomials
Polynomial Polynomial::compose(const Polynomial& other) const {
    Polynomial result; // Initialize to a zero polynomial using the default constructor
    for (int i = degree(); i >= 0; --i) {
        // Create a polynomial for the coefficient
        Polynomial termPoly({coeffs[i]}); // Create polynomial with the coefficient
        result = result + (termPoly * other.power(i)); // Multiply and add
    }
    return result;
}

// Helper function to calculate powers of the polynomial
Polynomial Polynomial::power(int exponent) const {
    Polynomial result({1.0}); // Start with polynomial 1
    Polynomial base = *this; // Current polynomial

    while (exponent > 0) {
        if (exponent % 2 == 1) {
            result = result * base; // Multiply result by base when odd
        }
        base = base * base; // Square the base
        exponent /= 2; // Divide the exponent by 2
    }

    return result; // Return final result
}