#include "Polynomial_copilot.h"
#include <iostream>
#include <vector>

using namespace std;

void printMenu() {
    cout << "Polynomial Menu:" << endl;
    cout << "1. Display Polynomial" << endl;
    cout << "2. Add Polynomials" << endl;
    cout << "3. Subtract Polynomials" << endl;
    cout << "4. Multiply Polynomials" << endl;
    cout << "5. Get Degree of Polynomial" << endl;
    cout << "6. Evaluate Polynomial" << endl;
    cout << "7. Compose Polynomials" << endl;
    cout << "8. Derivative of Polynomial" << endl;
    cout << "9. Integrate Polynomial" << endl;
    cout << "10. Definite Integral of Polynomial" << endl;
    cout << "11. Get Root of Polynomial" << endl;
    cout << "12. Set Coefficients" << endl;
    cout << "13. Get Coefficient" << endl;
    cout << "14. Check Equality of Polynomials" << endl;
    cout << "0. Exit" << endl;
}

void inputPolynomial(Polynomial& p) {
    int degree;
    cout << "Enter the degree of the polynomial: ";
    cin >> degree;
    vector<double> coeffs(degree + 1);
    cout << "Enter the coefficients (from constant term to highest degree): ";
    for (int i = 0; i <= degree; ++i) {
        cin >> coeffs[i];
    }
    p.setCoefficients(coeffs);
}

int selectPolynomial(const vector<Polynomial>& polys) {
    int index;
    cout << "Select a polynomial by its number: ";
    for (int i = 0; i < polys.size(); ++i) {
        cout << i + 1 << ": " << polys[i] << endl;
    }
    cin >> index;
    return index - 1;
}

int main() {
    vector<Polynomial> polynomials(3); // Create space for at least three polynomials
    for (int i = 0; i < polynomials.size(); ++i) {
        cout << "Enter polynomial " << i + 1 << ":" << endl;
        inputPolynomial(polynomials[i]);
    }

    bool running = true;

    while (running) {
        printMenu();
        int choice;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int index = selectPolynomial(polynomials);
                cout << "Polynomial: " << polynomials[index] << endl;
                break;
            }
            case 2: {
                int i1 = selectPolynomial(polynomials);
                int i2 = selectPolynomial(polynomials);
                Polynomial sum = polynomials[i1] + polynomials[i2];
                cout << "Sum: " << sum << endl;
                break;
            }
            case 3: {
                int i1 = selectPolynomial(polynomials);
                int i2 = selectPolynomial(polynomials);
                Polynomial diff = polynomials[i1] - polynomials[i2];
                cout << "Difference: " << diff << endl;
                break;
            }
            case 4: {
                int i1 = selectPolynomial(polynomials);
                int i2 = selectPolynomial(polynomials);
                Polynomial prod = polynomials[i1] * polynomials[i2];
                cout << "Product: " << prod << endl;
                break;
            }
            case 5: {
                int index = selectPolynomial(polynomials);
                cout << "Degree: " << polynomials[index].degree() << endl;
                break;
            }
            case 6: {
                int index = selectPolynomial(polynomials);
                double x;
                cout << "Enter the value of x: ";
                cin >> x;
                cout << "Evaluation at x = " << x << ": " << polynomials[index].evaluate(x) << endl;
                break;
            }
            case 7: {
                int i1 = selectPolynomial(polynomials);
                int i2 = selectPolynomial(polynomials);
                Polynomial comp = polynomials[i1].compose(polynomials[i2]);
                cout << "Composition: " << comp << endl;
                break;
            }
            case 8: {
                int index = selectPolynomial(polynomials);
                cout << "Derivative: " << polynomials[index].derivative() << endl;
                break;
            }
            case 9: {
                int index = selectPolynomial(polynomials);
                cout << "Integral: " << polynomials[index].integral() << endl;
                break;
            }
            case 10: {
                int index = selectPolynomial(polynomials);
                double x1, x2;
                cout << "Enter the range (x1 and x2): ";
                cin >> x1 >> x2;
                cout << "Definite Integral from " << x1 << " to " << x2 << ": " << polynomials[index].integral(x1, x2) << endl;
                break;
            }
            case 11: {
                int index = selectPolynomial(polynomials);
                double guess;
                cout << "Enter the initial guess for the root: ";
                cin >> guess;
                try {
                    cout << "Root: " << polynomials[index].getRoot(guess) << endl;
                } catch (const runtime_error& e) {
                    cerr << "Error: " << e.what() << endl;
                }
                break;
            }
            case 12: {
                int index = selectPolynomial(polynomials);
                inputPolynomial(polynomials[index]);
                cout << "Coefficients set." << endl;
                break;
            }
            case 13: {
                int index = selectPolynomial(polynomials);
                int degree;
                cout << "Enter the degree of the term: ";
                cin >> degree;
                try {
                    cout << "Coefficient: " << polynomials[index].getCoefficient(degree) << endl;
                } catch (const out_of_range& e) {
                    cerr << "Error: " << e.what() << endl;
                }
                break;
            }
            case 14: {
                int i1 = selectPolynomial(polynomials);
                int i2 = selectPolynomial(polynomials);
                bool equal = (polynomials[i1] == polynomials[i2]);
                cout << "Polynomials " << (equal ? "are" : "are not") << " equal." << endl;
                break;
            }
            case 0:
                running = false;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}
