#include "Polynomial.h"

// Default constructor
Polynomial::Polynomial() {}

// Constructor with coefficients
Polynomial::Polynomial(const vector<double>& coefficients) : coeffs(coefficients) {}

// Copy constructor
Polynomial::Polynomial(const Polynomial& other) : coeffs(other.coeffs) {}

// Destructor
Polynomial::~Polynomial() {}

// Assignment operator
Polynomial& Polynomial::operator=(const Polynomial& other) {
    if (this != &other) {
        coeffs = other.coeffs;
    }
    return *this;
}

// Arithmetic operators
Polynomial Polynomial::operator+(const Polynomial& other) const {
    vector<double> resultCoeffs(max(coeffs.size(), other.coeffs.size()), 0);
    for (size_t i = 0; i < coeffs.size(); ++i) {
        resultCoeffs[i] += coeffs[i];
    }
    for (size_t i = 0; i < other.coeffs.size(); ++i) {
        resultCoeffs[i] += other.coeffs[i];
    }
    return Polynomial(resultCoeffs);
}

Polynomial Polynomial::operator-(const Polynomial& other) const {
    vector<double> resultCoeffs(max(coeffs.size(), other.coeffs.size()), 0);
    for (size_t i = 0; i < coeffs.size(); ++i) {
        resultCoeffs[i] += coeffs[i];
    }
    for (size_t i = 0; i < other.coeffs.size(); ++i) {
        resultCoeffs[i] -= other.coeffs[i];
    }
    return Polynomial(resultCoeffs);
}

Polynomial Polynomial::operator*(const Polynomial& other) const {
    vector<double> resultCoeffs(coeffs.size() + other.coeffs.size() - 1, 0);
    for (size_t i = 0; i < coeffs.size(); ++i) {
        for (size_t j = 0; j < other.coeffs.size(); ++j) {
            resultCoeffs[i + j] += coeffs[i] * other.coeffs[j];
        }
    }
    return Polynomial(resultCoeffs);
}

// Equality operator
bool Polynomial::operator==(const Polynomial& other) const {
    return coeffs == other.coeffs;
}

// Output operator
ostream& operator<<(ostream& out, const Polynomial& poly) {
    for (int i = poly.coeffs.size() - 1; i >= 0; --i) {
        if (poly.coeffs[i] != 0) {
            if (i != poly.coeffs.size() - 1) out << " + ";
            out << poly.coeffs[i] << "x^" << i;
        }
    }
    return out;
}

// Utility functions
int Polynomial::degree() const {
    return coeffs.size() - 1;
}

double Polynomial::evaluate(double x) const {
    double result = 0;
    for (int i = degree(); i >= 0; --i) {
        result = result * x + coeffs[i];
    }
    return result;
}

Polynomial Polynomial::compose(const Polynomial& q) const {
    Polynomial result;
    for (int i = 0; i < coeffs.size(); ++i) {
        Polynomial temp = q;
        for (int j = 0; j < i; ++j) {
            temp = temp * q; // Compose polynomial
        }
        result = result + (temp * Polynomial({ coeffs[i] }));
    }
    return result;
}

Polynomial Polynomial::derivative() const {
    if (degree() == 0) return Polynomial();
    vector<double> derivedCoeffs(degree());
    for (int i = 1; i < coeffs.size(); ++i) {
        derivedCoeffs[i - 1] = coeffs[i] * i;
    }
    return Polynomial(derivedCoeffs);
}

Polynomial Polynomial::integral() const {
    vector<double> integralCoeffs(coeffs.size() + 1);
    for (int i = 0; i < coeffs.size(); ++i) {
        integralCoeffs[i + 1] = coeffs[i] / (i + 1);
    }
    integralCoeffs[0] = 0; // Constant of integration
    return Polynomial(integralCoeffs);
}

double Polynomial::integral(double x1, double x2) const {
    return evaluate(x2) - evaluate(x1);
}

double Polynomial::getRoot(double guess, double tolerance, int maxIter) {
    for (int i = 0; i < maxIter; ++i) {
        double f_val = evaluate(guess);
        double f_prime = derivative().evaluate(guess);
        if (abs(f_val) < tolerance) return guess; // Found the root
        if (f_prime == 0) break; // Derivative is zero, cannot proceed
        guess -= f_val / f_prime; // Newton's method
    }
    return guess; // Return the best guess
}

// Getter and Setter for polynomial coefficients
void Polynomial::setCoefficients(const vector<double>& coefficients) {
    coeffs = coefficients;
}

double Polynomial::getCoefficient(int degree) const {
    if (degree >= 0 && degree < coeffs.size()) {
        return coeffs[degree];
    }
    return 0; // Degree out of range
}
