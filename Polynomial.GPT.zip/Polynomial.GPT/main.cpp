#include <iostream>
#include <vector>
#include "polynomial.h"

using namespace std;

int main() {
    vector<Polynomial> polynomials;
    int choice;

    while (true) {
        cout << "\n******Polynomial Operations Menu******:\n";
        cout << "1. Create a new polynomial\n";
        cout << "2. Display a polynomial\n";
        cout << "3. Add two polynomials\n";
        cout << "4. Subtract two polynomials\n";
        cout << "5. Multiply two polynomials\n";
        cout << "6. Evaluate a polynomial\n";
        cout << "7. Find the derivative of a polynomial\n";
        cout << "8. Find the integral of a polynomial\n";
        cout << "9. Find definite integral from x1 to x2\n";
        cout << "10. Check equality of two polynomials\n";
        cout << "11. Find a root of a polynomial\n";
        cout << "12. Get a coefficient of a polynomial\n";
        cout << "13. Set coefficients of a polynomial\n";
        cout << "14. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int degree;
                cout << "Enter the degree of the polynomial: ";
                cin >> degree;
                vector<double> coefficients(degree + 1);
                cout << "Enter coefficients (from highest degree to constant): ";
                for (int i = 0; i <= degree; ++i) {
                    cin >> coefficients[i];
                }
                polynomials.emplace_back(coefficients);
                cout << "Polynomial created successfully.\n";
                break;
            }
            case 2: {
                int index;
                cout << "Enter the index of the polynomial to display (0 to " << polynomials.size() - 1 << "): ";
                cin >> index;
                if (index >= 0 && index < polynomials.size()) {
                    cout << "Polynomial: " << polynomials[index] << endl;
                } else {
                    cout << "Invalid index!\n";
                }
                break;
            }
            case 3: {
                int index1, index2;
                cout << "Enter the indices of the polynomials to add (0 to " << polynomials.size() - 1 << "): ";
                cin >> index1 >> index2;
                if (index1 >= 0 && index1 < polynomials.size() && index2 >= 0 && index2 < polynomials.size()) {
                    Polynomial result = polynomials[index1] + polynomials[index2];
                    cout << "Result: " << result << endl;
                } else {
                    cout << "Invalid indices!\n";
                }
                break;
            }
            case 4: {
                int index1, index2;
                cout << "Enter the indices of the polynomials to subtract (0 to " << polynomials.size() - 1 << "): ";
                cin >> index1 >> index2;
                if (index1 >= 0 && index1 < polynomials.size() && index2 >= 0 && index2 < polynomials.size()) {
                    Polynomial result = polynomials[index1] - polynomials[index2];
                    cout << "Result: " << result << endl;
                } else {
                    cout << "Invalid indices!\n";
                }
                break;
            }
            case 5: {
                int index1, index2;
                cout << "Enter the indices of the polynomials to multiply (0 to " << polynomials.size() - 1 << "): ";
                cin >> index1 >> index2;
                if (index1 >= 0 && index1 < polynomials.size() && index2 >= 0 && index2 < polynomials.size()) {
                    Polynomial result = polynomials[index1] * polynomials[index2];
                    cout << "Result: " << result << endl;
                } else {
                    cout << "Invalid indices!\n";
                }
                break;
            }
            case 6: {
                int index;
                double x;
                cout << "Enter the index of the polynomial to evaluate (0 to " << polynomials.size() - 1 << "): ";
                cin >> index;
                if (index >= 0 && index < polynomials.size()) {
                    cout << "Enter the value of x: ";
                    cin >> x;
                    double result = polynomials[index].evaluate(x);
                    cout << "Result: " << result << endl;
                } else {
                    cout << "Invalid index!\n";
                }
                break;
            }
            case 7: {
                int index;
                cout << "Enter the index of the polynomial to find its derivative (0 to " << polynomials.size() - 1 << "): ";
                cin >> index;
                if (index >= 0 && index < polynomials.size()) {
                    Polynomial result = polynomials[index].derivative();
                    cout << "Derivative: " << result << endl;
                } else {
                    cout << "Invalid index!\n";
                }
                break;
            }
            case 8: {
                int index;
                cout << "Enter the index of the polynomial to find its integral (0 to " << polynomials.size() - 1 << "): ";
                cin >> index;
                if (index >= 0 && index < polynomials.size()) {
                    Polynomial result = polynomials[index].integral();
                    cout << "Integral: " << result << endl;
                } else {
                    cout << "Invalid index!\n";
                }
                break;
            }
            case 9: {
                int index;
                double x1, x2;
                cout << "Enter the index of the polynomial to find its integral from x1 to x2 (0 to " << polynomials.size() - 1 << "): ";
                cin >> index;
                if (index >= 0 && index < polynomials.size()) {
                    cout << "Enter x1 and x2: ";
                    cin >> x1 >> x2;
                    double result = polynomials[index].integral(x1, x2);
                    cout << "Integral result: " << result << endl;
                } else {
                    cout << "Invalid index!\n";
                }
                break;
            }
            case 10: {
                int index1, index2;
                cout << "Enter the indices of the polynomials to check equality (0 to " << polynomials.size() - 1 << "): ";
                cin >> index1 >> index2;
                if (index1 >= 0 && index1 < polynomials.size() && index2 >= 0 && index2 < polynomials.size()) {
                    if (polynomials[index1] == polynomials[index2]) {
                        cout << "Polynomials are equal.\n";
                    } else {
                        cout << "Polynomials are not equal.\n";
                    }
                } else {
                    cout << "Invalid indices!\n";
                }
                break;
            }
            case 11: {
                int index;
                double guess;
                cout << "Enter the index of the polynomial to find its root (0 to " << polynomials.size() - 1 << "): ";
                cin >> index;
                if (index >= 0 && index < polynomials.size()) {
                    cout << "Enter initial guess: ";
                    cin >> guess;
                    double root = polynomials[index].getRoot(guess);
                    cout << "Approximate root: " << root << endl;
                } else {
                    cout << "Invalid index!\n";
                }
                break;
            }
            case 12: {
                int index, degree;
                cout << "Enter the index of the polynomial to get a coefficient (0 to " << polynomials.size() - 1 << "): ";
                cin >> index;
                if (index >= 0 && index < polynomials.size()) {
                    cout << "Enter the degree to get the coefficient: ";
                    cin >> degree;
                    double coeff = polynomials[index].getCoefficient(degree);
                    cout << "Coefficient: " << coeff << endl;
                } else {
                    cout << "Invalid index!\n";
                }
                break;
            }
            case 13: {
                int index;
                vector<double> coefficients;
                cout << "Enter the index of the polynomial to set coefficients (0 to " << polynomials.size() - 1 << "): ";
                cin >> index;
                if (index >= 0 && index < polynomials.size()) {
                    int degree;
                    cout << "Enter the degree of the polynomial: ";
                    cin >> degree;
                    coefficients.resize(degree + 1);
                    cout << "Enter coefficients (from highest degree to constant): ";
                    for (int i = 0; i <= degree; ++i) {
                        cin >> coefficients[i];
                    }
                    polynomials[index].setCoefficients(coefficients);
                    cout << "Coefficients set successfully.\n";
                } else {
                    cout << "Invalid index!\n";
                }
                break;
            }
            case 14:
                cout << "Exiting program.\n";
                return 0;
            default:
                cout << "Invalid choice! Please try again.\n";
        }
    }
    return 0;
}
